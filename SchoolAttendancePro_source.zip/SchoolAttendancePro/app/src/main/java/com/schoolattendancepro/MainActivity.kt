package com.schoolattendancepro

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

private const val ACTION_USB_PERMISSION = "com.schoolattendancepro.USB_PERMISSION"

data class AttendanceRow(
    val uid: String, val student: String, val status: String,
    val date: String, val time: String
)

class MainActivity : ComponentActivity() {
    private var port: UsbSerialPort? = null
    private var connected by mutableStateOf(false)
    private val rows = mutableStateListOf<AttendanceRow>()
    private var connectionMessage by mutableStateOf("USB not connected")

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ACTION_USB_PERMISSION) {
                val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && device != null) {
                    openDevice(device)
                } else connectionMessage = "USB permission was not granted"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(permissionReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(permissionReceiver, filter)
        loadRows()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF39A7FF), background = Color(0xFF0B1220),
                surface = Color(0xFF152238), onSurface = Color.White
            )) {
                Dashboard(
                    rows = rows.toList(),
                    connected = connected,
                    message = connectionMessage,
                    onConnect = { connectUsb() },
                    onDisconnect = { disconnectUsb() },
                    onCommand = { sendCommand(it) },
                    onClear = { rows.clear(); saveRows() }
                )
            }
        }
    }

    private fun connectUsb() {
        try {
            val manager = getSystemService(Context.USB_SERVICE) as UsbManager
            val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(manager)
            if (drivers.isEmpty()) {
                connectionMessage = "No supported USB serial device found. Check OTG cable and Arduino."
                return
            }
            val driver = drivers[0]
            if (!manager.hasPermission(driver.device)) {
                val pi = PendingIntent.getBroadcast(
                    this, 0, Intent(ACTION_USB_PERMISSION),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                manager.requestPermission(driver.device, pi)
            } else openDevice(driver.device)
        } catch (e: Exception) {
            connectionMessage = "USB error: ${e.message ?: "unknown"}"
        }
    }

    private fun openDevice(device: UsbDevice) {
        try {
            val manager = getSystemService(Context.USB_SERVICE) as UsbManager
            val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
                ?: throw IllegalStateException("Unsupported USB serial device")
            val connection = manager.openDevice(device)
                ?: throw IllegalStateException("Could not open USB device")
            val serialPort = driver.ports.first()
            serialPort.open(connection)
            serialPort.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            port = serialPort
            connected = true
            connectionMessage = "Connected at 9600 baud"
            startReading(serialPort)
        } catch (e: Exception) {
            connected = false
            connectionMessage = "Could not connect: ${e.message ?: "unknown error"}"
        }
    }

    private fun startReading(serialPort: UsbSerialPort) {
        thread(name = "usb-serial-reader") {
            val buffer = ByteArray(512)
            val pending = StringBuilder()
            while (connected && port === serialPort) {
                try {
                    val count = serialPort.read(buffer, 1000)
                    if (count > 0) {
                        pending.append(String(buffer, 0, count, Charsets.UTF_8))
                        while (pending.contains("\n")) {
                            val index = pending.indexOf("\n")
                            val line = pending.substring(0, index).trim()
                            pending.delete(0, index + 1)
                            if (line.isNotBlank()) runOnUiThread { handleLine(line) }
                        }
                    }
                } catch (_: Exception) {
                    runOnUiThread {
                        connected = false
                        connectionMessage = "USB connection lost"
                    }
                    break
                }
            }
        }
    }

    // Expected Arduino line: SCAN|UID|Student Name|IN or OUT|YYYY-MM-DD|HH:mm:ss
    private fun handleLine(line: String) {
        if (!line.startsWith("SCAN|")) {
            connectionMessage = "Arduino: $line"
            return
        }
        val p = line.split("|")
        if (p.size >= 6) {
            rows.add(0, AttendanceRow(p[1], p[2], p[3].uppercase(), p[4], p[5]))
            if (rows.size > 5000) rows.removeAt(rows.lastIndex)
            saveRows()
            connectionMessage = "New scan received"
        } else connectionMessage = "Unrecognized scan format"
    }

    private fun sendCommand(command: String) {
        try {
            port?.write((command + "\n").toByteArray(), 1000)
            connectionMessage = "Sent: $command"
        } catch (e: Exception) {
            connectionMessage = "Command failed: ${e.message ?: "USB disconnected"}"
        }
    }

    private fun disconnectUsb() {
        connected = false
        try { port?.close() } catch (_: Exception) {}
        port = null
        connectionMessage = "USB disconnected"
    }

    private fun saveRows() {
        val data = rows.joinToString("\n") {
            listOf(it.uid, it.student, it.status, it.date, it.time).joinToString("\t")
        }
        getSharedPreferences("attendance", MODE_PRIVATE).edit().putString("rows", data).apply()
    }

    private fun loadRows() {
        val data = getSharedPreferences("attendance", MODE_PRIVATE).getString("rows", "") ?: ""
        data.lines().filter { it.isNotBlank() }.forEach {
            val p = it.split("\t")
            if (p.size == 5) rows.add(AttendanceRow(p[0], p[1], p[2], p[3], p[4]))
        }
    }

    override fun onDestroy() {
        disconnectUsb()
        try { unregisterReceiver(permissionReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}

@Composable
private fun Dashboard(
    rows: List<AttendanceRow>, connected: Boolean, message: String,
    onConnect: () -> Unit, onDisconnect: () -> Unit,
    onCommand: (String) -> Unit, onClear: () -> Unit
) {
    var selectedTab by remember { mutableStateOf("Dashboard") }
    var dateFilter by remember { mutableStateOf("") }
    var adminCode by remember { mutableStateOf("") }
    var adminUnlocked by remember { mutableStateOf(false) }
    val present = rows.count { it.status == "IN" }
    val out = rows.count { it.status == "OUT" }
    val visible = rows.filter { dateFilter.isBlank() || it.date.contains(dateFilter) }

    Scaffold(containerColor = Color(0xFF0B1220)) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
            Text("School Attendance Pro", color = Color.White, fontSize = 23.sp)
            Text("خوێندنگە • بەڕێوەبردنی ئامادەبوون", color = Color(0xFF9DB4D0))
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).background(if (connected) Color(0xFF35D07F) else Color.Red, RoundedCornerShape(50)))
                Spacer(Modifier.width(8.dp))
                Text(message, color = Color(0xFFB8C7DA), fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onConnect, modifier = Modifier.weight(1f)) { Text("Connect USB") }
                OutlinedButton(onClick = onDisconnect, modifier = Modifier.weight(1f)) { Text("Disconnect") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Scans", rows.size.toString(), Modifier.weight(1f))
                StatCard("IN", present.toString(), Modifier.weight(1f))
                StatCard("OUT", out.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Dashboard", "Reports", "Principal").forEach { tab ->
                    FilterChip(selected = selectedTab == tab, onClick = { selectedTab = tab }, label = { Text(tab) })
                }
            }
            when (selectedTab) {
                "Dashboard" -> {
                    Text("Live RFID attendance", color = Color.White)
                    Text("Arduino sends: SCAN|UID|Name|IN/OUT|Date|Time", color = Color(0xFF91A6C2), fontSize = 11.sp)
                    AttendanceList(rows.take(8))
                }
                "Reports" -> {
                    OutlinedTextField(value = dateFilter, onValueChange = { dateFilter = it },
                        label = { Text("Date filter (YYYY-MM-DD)") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onCommand("SAVE_REPORT") }) { Text("Save report") }
                        OutlinedButton(onClick = { onCommand("SAVE_ALL") }) { Text("Save all") }
                    }
                    AttendanceList(visible)
                }
                "Principal" -> {
                    if (!adminUnlocked) {
                        OutlinedTextField(value = adminCode, onValueChange = { adminCode = it },
                            label = { Text("Principal code") }, singleLine = true)
                        Button(onClick = { adminUnlocked = adminCode == "2199"; adminCode = "" }) { Text("Unlock") }
                    } else {
                        Text("Principal control panel", color = Color.White)
                        Button(onClick = { onCommand("GET_REPORT") }) { Text("Get report") }
                        Button(onClick = { onCommand("SAVE_ALL") }) { Text("Save all records") }
                        Button(onClick = { onCommand("TEACHER_LIST") }) { Text("Teacher list") }
                        Button(onClick = { onCommand("LOCK") ; adminUnlocked = false }) { Text("Lock panel") }
                        Text("Teacher management and card registration require matching Arduino firmware.", color = Color(0xFF91A6C2), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier.padding(vertical = 10.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF152238))) {
        Column(Modifier.padding(12.dp)) {
            Text(value, color = Color.White, fontSize = 22.sp)
            Text(label, color = Color(0xFF9DB4D0), fontSize = 12.sp)
        }
    }
}

@Composable
private fun AttendanceList(rows: List<AttendanceRow>) {
    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
        items(rows) { row ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF152238))) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(row.student, color = Color.White)
                        Text("${row.uid} • ${row.date} ${row.time}", color = Color(0xFF9DB4D0), fontSize = 11.sp)
                    }
                    Text(row.status, color = if (row.status == "IN") Color(0xFF35D07F) else Color(0xFFFF6666))
                }
            }
        }
    }
}
