# SchoolAttendancePro

Android starter project for an offline Arduino Uno USB-OTG attendance dashboard.

## Build
The included GitHub Actions workflow builds a debug APK. Upload this project to a GitHub repository, then open Actions and run **Build SchoolAttendancePro APK**. Download the `SchoolAttendancePro-debug` artifact and install the APK on the Android phone.

## USB serial protocol
The app opens the first supported USB serial device at **9600 baud, 8-N-1**.
For each attendance scan, Arduino must send one newline-terminated UTF-8 line:

`SCAN|UID|Student Name|IN|YYYY-MM-DD|HH:mm:ss`

or

`SCAN|UID|Student Name|OUT|YYYY-MM-DD|HH:mm:ss`

Example:
`SCAN|A1B2C3D4|Ali Hassan|IN|2026-11-12|08:15:00`

The app stores received scans on the phone in local app storage. It does not require Wi-Fi or internet while scanning.

## Commands currently sent by the dashboard
`SAVE_REPORT`, `SAVE_ALL`, `GET_REPORT`, `TEACHER_LIST`, and `LOCK`, each followed by a newline. The Arduino firmware must implement any command it should act on.

## Important
This is a first buildable starter, not the finished school system. It currently provides USB serial connection, live scan display, local scan history, date filtering, and a principal-code-gated screen. Full teacher CRUD, student/card registration, export/share of reports, and robust IN/OUT logic need to be added together with the exact Arduino firmware protocol.
